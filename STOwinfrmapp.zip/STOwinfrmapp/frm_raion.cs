﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace STOwinfrmapp
{
    public partial class frm_raion : Form
    {
        public frm_raion()
        {
            InitializeComponent();
        }

        private void rayonBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.rayonBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.stoDataSet);

        }

        private void frm_raion_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'stoDataSet.rayon' table. You can move, or remove it, as needed.
            this.rayonTableAdapter.Fill(this.stoDataSet.rayon);

        }
    }
}
