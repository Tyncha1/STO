﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace STOwinfrmapp
{
    public partial class frm_pr_list : Form
    {
        public frm_pr_list()
        {
            InitializeComponent();
        }

        private void priceBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.priceBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.stoDataSet);

        }

        private void frm_pr_list_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'stoDataSet.rabota' table. You can move, or remove it, as needed.
            this.rabotaTableAdapter.Fill(this.stoDataSet.rabota);
            // TODO: This line of code loads data into the 'stoDataSet.tip_rab' table. You can move, or remove it, as needed.
            this.tip_rabTableAdapter.Fill(this.stoDataSet.tip_rab);
            // TODO: This line of code loads data into the 'stoDataSet.price' table. You can move, or remove it, as needed.
            this.priceTableAdapter.Fill(this.stoDataSet.price);

        }
    }
}
