﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace STOwinfrmapp
{
    public partial class frm_new_tp_rab : Form
    {
        public frm_new_tp_rab()
        {
            InitializeComponent();
        }

        private void tip_rabBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tip_rabBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.stoDataSet);

        }

        private void frm_new_tp_rab_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'stoDataSet.tip_rab' table. You can move, or remove it, as needed.
            this.tip_rabTableAdapter.Fill(this.stoDataSet.tip_rab);

        }
    }
}
