﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace STOwinfrmapp
{
    public partial class frm_kont : Form
    {
        public frm_kont()
        {
            InitializeComponent();
        }

        private void kontBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.kontBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.stoDataSet);

        }

        private void frm_kont_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'stoDataSet.tip_kont' table. You can move, or remove it, as needed.
            this.tip_kontTableAdapter.Fill(this.stoDataSet.tip_kont);
            // TODO: This line of code loads data into the 'stoDataSet.rayon' table. You can move, or remove it, as needed.
            this.rayonTableAdapter.Fill(this.stoDataSet.rayon);
            // TODO: This line of code loads data into the 'stoDataSet.kl' table. You can move, or remove it, as needed.
            this.klTableAdapter.Fill(this.stoDataSet.kl);
            // TODO: This line of code loads data into the 'stoDataSet.tip_kl' table. You can move, or remove it, as needed.
            this.tip_klTableAdapter.Fill(this.stoDataSet.tip_kl);
            // TODO: This line of code loads data into the 'stoDataSet.kont' table. You can move, or remove it, as needed.
            this.kontTableAdapter.Fill(this.stoDataSet.kont);

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                this.klTableAdapter.FillBy(this.stoDataSet.kl, textBox1.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
        }

        private void kontBindingNavigator_RefreshItems(object sender, EventArgs e)
        {

        }
    }
}
