﻿namespace STOwinfrmapp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.спаровочникиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.типКонтактовToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.типЗаказовToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оплатаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.должностиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.типРаботыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сотрудникиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ценаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.работаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.типАвтоToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.маркаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.районToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.типКлиентовToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.клиентыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.журналыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.клиентыToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.заказToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оплатаToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.прайсЛистToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.составToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запрсыПоисковыеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.актуальныйПрайсЛистToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оплатаЗаПериодToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.статистическиеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поРайонамToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поТипуАвтоToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.маркеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.типуЗаказаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.клиенПоЗаказToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оплатаПоРайонамToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.составЗаказаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.историяЦенЗаПерToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.спаровочникиToolStripMenuItem,
            this.журналыToolStripMenuItem,
            this.запрсыПоисковыеToolStripMenuItem,
            this.статистическиеToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // спаровочникиToolStripMenuItem
            // 
            this.спаровочникиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.типКонтактовToolStripMenuItem,
            this.типЗаказовToolStripMenuItem,
            this.оплатаToolStripMenuItem,
            this.должностиToolStripMenuItem,
            this.типРаботыToolStripMenuItem,
            this.сотрудникиToolStripMenuItem,
            this.ценаToolStripMenuItem,
            this.работаToolStripMenuItem,
            this.типАвтоToolStripMenuItem,
            this.маркаToolStripMenuItem,
            this.районToolStripMenuItem,
            this.типКлиентовToolStripMenuItem,
            this.клиентыToolStripMenuItem});
            this.спаровочникиToolStripMenuItem.Name = "спаровочникиToolStripMenuItem";
            this.спаровочникиToolStripMenuItem.Size = new System.Drawing.Size(101, 20);
            this.спаровочникиToolStripMenuItem.Text = "Спаровочники";
            // 
            // типКонтактовToolStripMenuItem
            // 
            this.типКонтактовToolStripMenuItem.Name = "типКонтактовToolStripMenuItem";
            this.типКонтактовToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.типКонтактовToolStripMenuItem.Text = "Тип контактов ";
            this.типКонтактовToolStripMenuItem.Click += new System.EventHandler(this.типКонтактовToolStripMenuItem_Click);
            // 
            // типЗаказовToolStripMenuItem
            // 
            this.типЗаказовToolStripMenuItem.Name = "типЗаказовToolStripMenuItem";
            this.типЗаказовToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.типЗаказовToolStripMenuItem.Text = "Тип заказов";
            this.типЗаказовToolStripMenuItem.Click += new System.EventHandler(this.типЗаказовToolStripMenuItem_Click);
            // 
            // оплатаToolStripMenuItem
            // 
            this.оплатаToolStripMenuItem.Name = "оплатаToolStripMenuItem";
            this.оплатаToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.оплатаToolStripMenuItem.Text = "Оплата";
            this.оплатаToolStripMenuItem.Click += new System.EventHandler(this.оплатаToolStripMenuItem_Click);
            // 
            // должностиToolStripMenuItem
            // 
            this.должностиToolStripMenuItem.Name = "должностиToolStripMenuItem";
            this.должностиToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.должностиToolStripMenuItem.Text = "Должности";
            this.должностиToolStripMenuItem.Click += new System.EventHandler(this.должностиToolStripMenuItem_Click);
            // 
            // типРаботыToolStripMenuItem
            // 
            this.типРаботыToolStripMenuItem.Name = "типРаботыToolStripMenuItem";
            this.типРаботыToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.типРаботыToolStripMenuItem.Text = "Тип работы";
            this.типРаботыToolStripMenuItem.Click += new System.EventHandler(this.типРаботыToolStripMenuItem_Click);
            // 
            // сотрудникиToolStripMenuItem
            // 
            this.сотрудникиToolStripMenuItem.Name = "сотрудникиToolStripMenuItem";
            this.сотрудникиToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.сотрудникиToolStripMenuItem.Text = "Сотрудники";
            this.сотрудникиToolStripMenuItem.Click += new System.EventHandler(this.сотрудникиToolStripMenuItem_Click);
            // 
            // ценаToolStripMenuItem
            // 
            this.ценаToolStripMenuItem.Name = "ценаToolStripMenuItem";
            this.ценаToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.ценаToolStripMenuItem.Text = "Цена ";
            this.ценаToolStripMenuItem.Click += new System.EventHandler(this.ценаToolStripMenuItem_Click);
            // 
            // работаToolStripMenuItem
            // 
            this.работаToolStripMenuItem.Name = "работаToolStripMenuItem";
            this.работаToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.работаToolStripMenuItem.Text = "Работа";
            this.работаToolStripMenuItem.Click += new System.EventHandler(this.работаToolStripMenuItem_Click);
            // 
            // типАвтоToolStripMenuItem
            // 
            this.типАвтоToolStripMenuItem.Name = "типАвтоToolStripMenuItem";
            this.типАвтоToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.типАвтоToolStripMenuItem.Text = "Тип авто";
            this.типАвтоToolStripMenuItem.Click += new System.EventHandler(this.типАвтоToolStripMenuItem_Click);
            // 
            // маркаToolStripMenuItem
            // 
            this.маркаToolStripMenuItem.Name = "маркаToolStripMenuItem";
            this.маркаToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.маркаToolStripMenuItem.Text = "Марка";
            this.маркаToolStripMenuItem.Click += new System.EventHandler(this.маркаToolStripMenuItem_Click);
            // 
            // районToolStripMenuItem
            // 
            this.районToolStripMenuItem.Name = "районToolStripMenuItem";
            this.районToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.районToolStripMenuItem.Text = "Район";
            this.районToolStripMenuItem.Click += new System.EventHandler(this.районToolStripMenuItem_Click);
            // 
            // типКлиентовToolStripMenuItem
            // 
            this.типКлиентовToolStripMenuItem.Name = "типКлиентовToolStripMenuItem";
            this.типКлиентовToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.типКлиентовToolStripMenuItem.Text = "Тип клиентов";
            this.типКлиентовToolStripMenuItem.Click += new System.EventHandler(this.типКлиентовToolStripMenuItem_Click);
            // 
            // клиентыToolStripMenuItem
            // 
            this.клиентыToolStripMenuItem.Name = "клиентыToolStripMenuItem";
            this.клиентыToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.клиентыToolStripMenuItem.Text = "Клиенты";
            this.клиентыToolStripMenuItem.Click += new System.EventHandler(this.клиентыToolStripMenuItem_Click);
            // 
            // журналыToolStripMenuItem
            // 
            this.журналыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.клиентыToolStripMenuItem1,
            this.заказToolStripMenuItem,
            this.оплатаToolStripMenuItem1,
            this.прайсЛистToolStripMenuItem,
            this.составToolStripMenuItem});
            this.журналыToolStripMenuItem.Name = "журналыToolStripMenuItem";
            this.журналыToolStripMenuItem.Size = new System.Drawing.Size(72, 20);
            this.журналыToolStripMenuItem.Text = "Журналы";
            this.журналыToolStripMenuItem.Click += new System.EventHandler(this.журналыToolStripMenuItem_Click);
            // 
            // клиентыToolStripMenuItem1
            // 
            this.клиентыToolStripMenuItem1.Name = "клиентыToolStripMenuItem1";
            this.клиентыToolStripMenuItem1.Size = new System.Drawing.Size(138, 22);
            this.клиентыToolStripMenuItem1.Text = "Контакты";
            this.клиентыToolStripMenuItem1.Click += new System.EventHandler(this.клиентыToolStripMenuItem1_Click);
            // 
            // заказToolStripMenuItem
            // 
            this.заказToolStripMenuItem.Name = "заказToolStripMenuItem";
            this.заказToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.заказToolStripMenuItem.Text = "Заказ ";
            this.заказToolStripMenuItem.Click += new System.EventHandler(this.заказToolStripMenuItem_Click);
            // 
            // оплатаToolStripMenuItem1
            // 
            this.оплатаToolStripMenuItem1.Name = "оплатаToolStripMenuItem1";
            this.оплатаToolStripMenuItem1.Size = new System.Drawing.Size(138, 22);
            this.оплатаToolStripMenuItem1.Text = "Оплата";
            this.оплатаToolStripMenuItem1.Click += new System.EventHandler(this.оплатаToolStripMenuItem1_Click);
            // 
            // прайсЛистToolStripMenuItem
            // 
            this.прайсЛистToolStripMenuItem.Name = "прайсЛистToolStripMenuItem";
            this.прайсЛистToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.прайсЛистToolStripMenuItem.Text = "Прайс Лист";
            this.прайсЛистToolStripMenuItem.Click += new System.EventHandler(this.прайсЛистToolStripMenuItem_Click);
            // 
            // составToolStripMenuItem
            // 
            this.составToolStripMenuItem.Name = "составToolStripMenuItem";
            this.составToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.составToolStripMenuItem.Text = "Состав";
            this.составToolStripMenuItem.Click += new System.EventHandler(this.составToolStripMenuItem_Click);
            // 
            // запрсыПоисковыеToolStripMenuItem
            // 
            this.запрсыПоисковыеToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.актуальныйПрайсЛистToolStripMenuItem,
            this.оплатаЗаПериодToolStripMenuItem});
            this.запрсыПоисковыеToolStripMenuItem.Name = "запрсыПоисковыеToolStripMenuItem";
            this.запрсыПоисковыеToolStripMenuItem.Size = new System.Drawing.Size(125, 20);
            this.запрсыПоисковыеToolStripMenuItem.Text = "Запрсы поисковые";
            // 
            // актуальныйПрайсЛистToolStripMenuItem
            // 
            this.актуальныйПрайсЛистToolStripMenuItem.Name = "актуальныйПрайсЛистToolStripMenuItem";
            this.актуальныйПрайсЛистToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.актуальныйПрайсЛистToolStripMenuItem.Text = "Актуальный прайс лист";
            this.актуальныйПрайсЛистToolStripMenuItem.Click += new System.EventHandler(this.актуальныйПрайсЛистToolStripMenuItem_Click);
            // 
            // оплатаЗаПериодToolStripMenuItem
            // 
            this.оплатаЗаПериодToolStripMenuItem.Name = "оплатаЗаПериодToolStripMenuItem";
            this.оплатаЗаПериодToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.оплатаЗаПериодToolStripMenuItem.Text = "Оплата за период";
            this.оплатаЗаПериодToolStripMenuItem.Click += new System.EventHandler(this.оплатаЗаПериодToolStripMenuItem_Click);
            // 
            // статистическиеToolStripMenuItem
            // 
            this.статистическиеToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.поРайонамToolStripMenuItem,
            this.поТипуАвтоToolStripMenuItem,
            this.маркеToolStripMenuItem,
            this.типуЗаказаToolStripMenuItem,
            this.клиенПоЗаказToolStripMenuItem,
            this.оплатаПоРайонамToolStripMenuItem,
            this.составЗаказаToolStripMenuItem,
            this.историяЦенЗаПерToolStripMenuItem});
            this.статистическиеToolStripMenuItem.Name = "статистическиеToolStripMenuItem";
            this.статистическиеToolStripMenuItem.Size = new System.Drawing.Size(106, 20);
            this.статистическиеToolStripMenuItem.Text = "Статистические";
            // 
            // поРайонамToolStripMenuItem
            // 
            this.поРайонамToolStripMenuItem.Name = "поРайонамToolStripMenuItem";
            this.поРайонамToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.поРайонамToolStripMenuItem.Text = "По районам";
            this.поРайонамToolStripMenuItem.Click += new System.EventHandler(this.поРайонамToolStripMenuItem_Click);
            // 
            // поТипуАвтоToolStripMenuItem
            // 
            this.поТипуАвтоToolStripMenuItem.Name = "поТипуАвтоToolStripMenuItem";
            this.поТипуАвтоToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.поТипуАвтоToolStripMenuItem.Text = "По типу авто";
            this.поТипуАвтоToolStripMenuItem.Click += new System.EventHandler(this.поТипуАвтоToolStripMenuItem_Click);
            // 
            // маркеToolStripMenuItem
            // 
            this.маркеToolStripMenuItem.Name = "маркеToolStripMenuItem";
            this.маркеToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.маркеToolStripMenuItem.Text = "Марке";
            this.маркеToolStripMenuItem.Click += new System.EventHandler(this.маркеToolStripMenuItem_Click);
            // 
            // типуЗаказаToolStripMenuItem
            // 
            this.типуЗаказаToolStripMenuItem.Name = "типуЗаказаToolStripMenuItem";
            this.типуЗаказаToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.типуЗаказаToolStripMenuItem.Text = "Типу заказа";
            this.типуЗаказаToolStripMenuItem.Click += new System.EventHandler(this.типуЗаказаToolStripMenuItem_Click);
            // 
            // клиенПоЗаказToolStripMenuItem
            // 
            this.клиенПоЗаказToolStripMenuItem.Name = "клиенПоЗаказToolStripMenuItem";
            this.клиенПоЗаказToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.клиенПоЗаказToolStripMenuItem.Text = "Клиен по заказ";
            // 
            // оплатаПоРайонамToolStripMenuItem
            // 
            this.оплатаПоРайонамToolStripMenuItem.Name = "оплатаПоРайонамToolStripMenuItem";
            this.оплатаПоРайонамToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.оплатаПоРайонамToolStripMenuItem.Text = "Оплата по районам";
            // 
            // составЗаказаToolStripMenuItem
            // 
            this.составЗаказаToolStripMenuItem.Name = "составЗаказаToolStripMenuItem";
            this.составЗаказаToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.составЗаказаToolStripMenuItem.Text = "Состав заказа";
            // 
            // историяЦенЗаПерToolStripMenuItem
            // 
            this.историяЦенЗаПерToolStripMenuItem.Name = "историяЦенЗаПерToolStripMenuItem";
            this.историяЦенЗаПерToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.историяЦенЗаПерToolStripMenuItem.Text = "История цен за пер";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem спаровочникиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem типКонтактовToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem типЗаказовToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оплатаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem должностиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem типРаботыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сотрудникиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ценаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem работаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem типАвтоToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem маркаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem районToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem типКлиентовToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem клиентыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem журналыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem клиентыToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem заказToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оплатаToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem прайсЛистToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem составToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запрсыПоисковыеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem актуальныйПрайсЛистToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оплатаЗаПериодToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem статистическиеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поРайонамToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поТипуАвтоToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem маркеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem типуЗаказаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem клиенПоЗаказToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оплатаПоРайонамToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem составЗаказаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem историяЦенЗаПерToolStripMenuItem;
    }
}

