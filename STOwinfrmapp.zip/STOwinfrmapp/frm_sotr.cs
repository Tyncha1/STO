﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace STOwinfrmapp
{
    public partial class frm_sotr : Form
    {
        public frm_sotr()
        {
            InitializeComponent();
        }

        private void sotrBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.sotrBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.stoDataSet);

        }

        private void frm_sotr_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'stoDataSet.dolj' table. You can move, or remove it, as needed.
            this.doljTableAdapter.Fill(this.stoDataSet.dolj);
            // TODO: This line of code loads data into the 'stoDataSet.sotr' table. You can move, or remove it, as needed.
            this.sotrTableAdapter.Fill(this.stoDataSet.sotr);

        }
    }
}
