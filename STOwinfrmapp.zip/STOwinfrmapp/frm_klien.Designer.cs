﻿namespace STOwinfrmapp
{
    partial class frm_klien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_klien));
            this.stoDataSet = new STOwinfrmapp.StoDataSet();
            this.klBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.klTableAdapter = new STOwinfrmapp.StoDataSetTableAdapters.klTableAdapter();
            this.tableAdapterManager = new STOwinfrmapp.StoDataSetTableAdapters.TableAdapterManager();
            this.klBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.fKklidtipkl21B6055DBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tip_klBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.klBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.klDataGridView = new System.Windows.Forms.DataGridView();
            this.rayonBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.tip_klTableAdapter = new STOwinfrmapp.StoDataSetTableAdapters.tip_klTableAdapter();
            this.tip_klComboBox = new System.Windows.Forms.ComboBox();
            this.Поиск = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.rabotaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rabotaTableAdapter = new STOwinfrmapp.StoDataSetTableAdapters.rabotaTableAdapter();
            this.rayonTableAdapter = new STOwinfrmapp.StoDataSetTableAdapters.rayonTableAdapter();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.stoDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.klBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.klBindingNavigator)).BeginInit();
            this.klBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fKklidtipkl21B6055DBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tip_klBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.klDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rayonBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rabotaBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // stoDataSet
            // 
            this.stoDataSet.DataSetName = "StoDataSet";
            this.stoDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // klBindingSource
            // 
            this.klBindingSource.DataMember = "kl";
            this.klBindingSource.DataSource = this.stoDataSet;
            // 
            // klTableAdapter
            // 
            this.klTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.doljTableAdapter = null;
            this.tableAdapterManager.klTableAdapter = this.klTableAdapter;
            this.tableAdapterManager.kontTableAdapter = null;
            this.tableAdapterManager.markaTableAdapter = null;
            this.tableAdapterManager.oplataTableAdapter = null;
            this.tableAdapterManager.priceTableAdapter = null;
            this.tableAdapterManager.rabotaTableAdapter = null;
            this.tableAdapterManager.rayonTableAdapter = null;
            this.tableAdapterManager.sostav_zTableAdapter = null;
            this.tableAdapterManager.sotrTableAdapter = null;
            this.tableAdapterManager.tip_avtoTableAdapter = null;
            this.tableAdapterManager.tip_klTableAdapter = null;
            this.tableAdapterManager.tip_kontTableAdapter = null;
            this.tableAdapterManager.tip_oplatyTableAdapter = null;
            this.tableAdapterManager.tip_rabTableAdapter = null;
            this.tableAdapterManager.tip_zakazaTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = STOwinfrmapp.StoDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.zakazTableAdapter = null;
            // 
            // klBindingNavigator
            // 
            this.klBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.klBindingNavigator.BindingSource = this.fKklidtipkl21B6055DBindingSource;
            this.klBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.klBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.klBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.klBindingNavigatorSaveItem});
            this.klBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.klBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.klBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.klBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.klBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.klBindingNavigator.Name = "klBindingNavigator";
            this.klBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.klBindingNavigator.Size = new System.Drawing.Size(1156, 25);
            this.klBindingNavigator.TabIndex = 0;
            this.klBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // fKklidtipkl21B6055DBindingSource
            // 
            this.fKklidtipkl21B6055DBindingSource.DataMember = "FK__kl__id_tip_kl__21B6055D";
            this.fKklidtipkl21B6055DBindingSource.DataSource = this.tip_klBindingSource;
            // 
            // tip_klBindingSource
            // 
            this.tip_klBindingSource.DataMember = "tip_kl";
            this.tip_klBindingSource.DataSource = this.stoDataSet;
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // klBindingNavigatorSaveItem
            // 
            this.klBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.klBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("klBindingNavigatorSaveItem.Image")));
            this.klBindingNavigatorSaveItem.Name = "klBindingNavigatorSaveItem";
            this.klBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.klBindingNavigatorSaveItem.Text = "Save Data";
            this.klBindingNavigatorSaveItem.Click += new System.EventHandler(this.klBindingNavigatorSaveItem_Click);
            // 
            // klDataGridView
            // 
            this.klDataGridView.AutoGenerateColumns = false;
            this.klDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.klDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn11});
            this.klDataGridView.DataSource = this.fKklidtipkl21B6055DBindingSource;
            this.klDataGridView.Location = new System.Drawing.Point(12, 100);
            this.klDataGridView.Name = "klDataGridView";
            this.klDataGridView.Size = new System.Drawing.Size(1076, 220);
            this.klDataGridView.TabIndex = 1;
            // 
            // rayonBindingSource
            // 
            this.rayonBindingSource.DataMember = "rayon";
            this.rayonBindingSource.DataSource = this.stoDataSet;
            // 
            // tip_klTableAdapter
            // 
            this.tip_klTableAdapter.ClearBeforeFill = true;
            // 
            // tip_klComboBox
            // 
            this.tip_klComboBox.DataSource = this.tip_klBindingSource;
            this.tip_klComboBox.DisplayMember = "tip_kl";
            this.tip_klComboBox.FormattingEnabled = true;
            this.tip_klComboBox.Location = new System.Drawing.Point(54, 59);
            this.tip_klComboBox.Name = "tip_klComboBox";
            this.tip_klComboBox.Size = new System.Drawing.Size(300, 21);
            this.tip_klComboBox.TabIndex = 2;
            this.tip_klComboBox.ValueMember = "id_tip_kl";
            // 
            // Поиск
            // 
            this.Поиск.Location = new System.Drawing.Point(990, 57);
            this.Поиск.Name = "Поиск";
            this.Поиск.Size = new System.Drawing.Size(75, 23);
            this.Поиск.TabIndex = 3;
            this.Поиск.Text = "button1";
            this.Поиск.UseVisualStyleBackColor = true;
            this.Поиск.Click += new System.EventHandler(this.Поиск_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(820, 57);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(164, 20);
            this.textBox1.TabIndex = 4;
            // 
            // rabotaBindingSource
            // 
            this.rabotaBindingSource.DataMember = "rabota";
            this.rabotaBindingSource.DataSource = this.stoDataSet;
            // 
            // rabotaTableAdapter
            // 
            this.rabotaTableAdapter.ClearBeforeFill = true;
            // 
            // rayonTableAdapter
            // 
            this.rayonTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "id_kl";
            this.dataGridViewTextBoxColumn1.HeaderText = "id_kl";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "imya";
            this.dataGridViewTextBoxColumn2.HeaderText = "imya";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "fam";
            this.dataGridViewTextBoxColumn3.HeaderText = "fam";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "otch";
            this.dataGridViewTextBoxColumn4.HeaderText = "otch";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "data_r";
            this.dataGridViewTextBoxColumn5.HeaderText = "data_r";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "mesto_r";
            this.dataGridViewTextBoxColumn6.HeaderText = "mesto_r";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "dolj";
            this.dataGridViewTextBoxColumn7.HeaderText = "dolj";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "skidka";
            this.dataGridViewTextBoxColumn8.HeaderText = "skidka";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "pasport_num";
            this.dataGridViewTextBoxColumn9.HeaderText = "pasport_num";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "id_rayon";
            this.dataGridViewTextBoxColumn11.DataSource = this.rayonBindingSource;
            this.dataGridViewTextBoxColumn11.DisplayMember = "rayon";
            this.dataGridViewTextBoxColumn11.HeaderText = "id_rayon";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn11.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn11.ValueMember = "id_rayon";
            // 
            // frm_klien
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1156, 450);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Поиск);
            this.Controls.Add(this.tip_klComboBox);
            this.Controls.Add(this.klDataGridView);
            this.Controls.Add(this.klBindingNavigator);
            this.Name = "frm_klien";
            this.Text = "frm_klien";
            this.Load += new System.EventHandler(this.frm_klien_Load);
            ((System.ComponentModel.ISupportInitialize)(this.stoDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.klBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.klBindingNavigator)).EndInit();
            this.klBindingNavigator.ResumeLayout(false);
            this.klBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fKklidtipkl21B6055DBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tip_klBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.klDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rayonBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rabotaBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private StoDataSet stoDataSet;
        private System.Windows.Forms.BindingSource klBindingSource;
        private StoDataSetTableAdapters.klTableAdapter klTableAdapter;
        private StoDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator klBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton klBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView klDataGridView;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.BindingSource tip_klBindingSource;
        private StoDataSetTableAdapters.tip_klTableAdapter tip_klTableAdapter;
        private System.Windows.Forms.BindingSource fKklidtipkl21B6055DBindingSource;
        private System.Windows.Forms.ComboBox tip_klComboBox;
        private System.Windows.Forms.Button Поиск;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.BindingSource rabotaBindingSource;
        private StoDataSetTableAdapters.rabotaTableAdapter rabotaTableAdapter;
        private System.Windows.Forms.BindingSource rayonBindingSource;
        private StoDataSetTableAdapters.rayonTableAdapter rayonTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn11;
    }
}