﻿namespace STOwinfrmapp
{
    partial class fq_opl_za_per
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fq_opl_za_per));
            this.stoDataSet = new STOwinfrmapp.StoDataSet();
            this.sp_opl_perBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sp_opl_perTableAdapter = new STOwinfrmapp.StoDataSetTableAdapters.sp_opl_perTableAdapter();
            this.tableAdapterManager = new STOwinfrmapp.StoDataSetTableAdapters.TableAdapterManager();
            this.sp_opl_perBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.sp_opl_perBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.fillToolStrip = new System.Windows.Forms.ToolStrip();
            this.d1ToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.d1ToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.d2ToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.d2ToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.fillToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.sp_opl_perDataGridView = new System.Windows.Forms.DataGridView();
            this.Запрос = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.stoDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sp_opl_perBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sp_opl_perBindingNavigator)).BeginInit();
            this.sp_opl_perBindingNavigator.SuspendLayout();
            this.fillToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sp_opl_perDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // stoDataSet
            // 
            this.stoDataSet.DataSetName = "StoDataSet";
            this.stoDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sp_opl_perBindingSource
            // 
            this.sp_opl_perBindingSource.DataMember = "sp_opl_per";
            this.sp_opl_perBindingSource.DataSource = this.stoDataSet;
            // 
            // sp_opl_perTableAdapter
            // 
            this.sp_opl_perTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Connection = null;
            this.tableAdapterManager.doljTableAdapter = null;
            this.tableAdapterManager.klTableAdapter = null;
            this.tableAdapterManager.kontTableAdapter = null;
            this.tableAdapterManager.markaTableAdapter = null;
            this.tableAdapterManager.oplataTableAdapter = null;
            this.tableAdapterManager.priceTableAdapter = null;
            this.tableAdapterManager.rabotaTableAdapter = null;
            this.tableAdapterManager.rayonTableAdapter = null;
            this.tableAdapterManager.sostav_zTableAdapter = null;
            this.tableAdapterManager.sotrTableAdapter = null;
            this.tableAdapterManager.tip_avtoTableAdapter = null;
            this.tableAdapterManager.tip_klTableAdapter = null;
            this.tableAdapterManager.tip_kontTableAdapter = null;
            this.tableAdapterManager.tip_oplatyTableAdapter = null;
            this.tableAdapterManager.tip_rabTableAdapter = null;
            this.tableAdapterManager.tip_zakazaTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = STOwinfrmapp.StoDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.zakazTableAdapter = null;
            // 
            // sp_opl_perBindingNavigator
            // 
            this.sp_opl_perBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.sp_opl_perBindingNavigator.BindingSource = this.sp_opl_perBindingSource;
            this.sp_opl_perBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.sp_opl_perBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.sp_opl_perBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.sp_opl_perBindingNavigatorSaveItem});
            this.sp_opl_perBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.sp_opl_perBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.sp_opl_perBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.sp_opl_perBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.sp_opl_perBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.sp_opl_perBindingNavigator.Name = "sp_opl_perBindingNavigator";
            this.sp_opl_perBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.sp_opl_perBindingNavigator.Size = new System.Drawing.Size(800, 25);
            this.sp_opl_perBindingNavigator.TabIndex = 0;
            this.sp_opl_perBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // sp_opl_perBindingNavigatorSaveItem
            // 
            this.sp_opl_perBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.sp_opl_perBindingNavigatorSaveItem.Enabled = false;
            this.sp_opl_perBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("sp_opl_perBindingNavigatorSaveItem.Image")));
            this.sp_opl_perBindingNavigatorSaveItem.Name = "sp_opl_perBindingNavigatorSaveItem";
            this.sp_opl_perBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.sp_opl_perBindingNavigatorSaveItem.Text = "Save Data";
            // 
            // fillToolStrip
            // 
            this.fillToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.d1ToolStripLabel,
            this.d1ToolStripTextBox,
            this.d2ToolStripLabel,
            this.d2ToolStripTextBox,
            this.fillToolStripButton});
            this.fillToolStrip.Location = new System.Drawing.Point(0, 25);
            this.fillToolStrip.Name = "fillToolStrip";
            this.fillToolStrip.Size = new System.Drawing.Size(800, 25);
            this.fillToolStrip.TabIndex = 1;
            this.fillToolStrip.Text = "fillToolStrip";
            // 
            // d1ToolStripLabel
            // 
            this.d1ToolStripLabel.Name = "d1ToolStripLabel";
            this.d1ToolStripLabel.Size = new System.Drawing.Size(23, 22);
            this.d1ToolStripLabel.Text = "d1:";
            // 
            // d1ToolStripTextBox
            // 
            this.d1ToolStripTextBox.Name = "d1ToolStripTextBox";
            this.d1ToolStripTextBox.Size = new System.Drawing.Size(100, 25);
            // 
            // d2ToolStripLabel
            // 
            this.d2ToolStripLabel.Name = "d2ToolStripLabel";
            this.d2ToolStripLabel.Size = new System.Drawing.Size(23, 22);
            this.d2ToolStripLabel.Text = "d2:";
            // 
            // d2ToolStripTextBox
            // 
            this.d2ToolStripTextBox.Name = "d2ToolStripTextBox";
            this.d2ToolStripTextBox.Size = new System.Drawing.Size(100, 25);
            // 
            // fillToolStripButton
            // 
            this.fillToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillToolStripButton.Name = "fillToolStripButton";
            this.fillToolStripButton.Size = new System.Drawing.Size(26, 22);
            this.fillToolStripButton.Text = "Fill";
            this.fillToolStripButton.Click += new System.EventHandler(this.fillToolStripButton_Click);
            // 
            // sp_opl_perDataGridView
            // 
            this.sp_opl_perDataGridView.AutoGenerateColumns = false;
            this.sp_opl_perDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.sp_opl_perDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3});
            this.sp_opl_perDataGridView.DataSource = this.sp_opl_perBindingSource;
            this.sp_opl_perDataGridView.Location = new System.Drawing.Point(12, 107);
            this.sp_opl_perDataGridView.Name = "sp_opl_perDataGridView";
            this.sp_opl_perDataGridView.Size = new System.Drawing.Size(765, 331);
            this.sp_opl_perDataGridView.TabIndex = 2;
            // 
            // Запрос
            // 
            this.Запрос.Location = new System.Drawing.Point(692, 69);
            this.Запрос.Name = "Запрос";
            this.Запрос.Size = new System.Drawing.Size(75, 23);
            this.Запрос.TabIndex = 3;
            this.Запрос.Text = "button1";
            this.Запрос.UseVisualStyleBackColor = true;
            this.Запрос.Click += new System.EventHandler(this.button1_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(60, 72);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 4;
            this.dateTimePicker1.Value = new System.DateTime(2021, 1, 1, 21, 29, 0, 0);
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(278, 72);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker2.TabIndex = 5;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "id_zakaz";
            this.dataGridViewTextBoxColumn1.HeaderText = "id_zakaz";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "tip_oplaty";
            this.dataGridViewTextBoxColumn2.HeaderText = "tip_oplaty";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "summa";
            this.dataGridViewTextBoxColumn3.HeaderText = "summa";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.Location = new System.Drawing.Point(25, 72);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker3.TabIndex = 4;
            this.dateTimePicker3.Value = new System.DateTime(2021, 1, 1, 21, 29, 0, 0);
            // 
            // fq_opl_za_per
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.dateTimePicker3);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.Запрос);
            this.Controls.Add(this.sp_opl_perDataGridView);
            this.Controls.Add(this.fillToolStrip);
            this.Controls.Add(this.sp_opl_perBindingNavigator);
            this.Name = "fq_opl_za_per";
            this.Text = "fq_opl_za_per";
            ((System.ComponentModel.ISupportInitialize)(this.stoDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sp_opl_perBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sp_opl_perBindingNavigator)).EndInit();
            this.sp_opl_perBindingNavigator.ResumeLayout(false);
            this.sp_opl_perBindingNavigator.PerformLayout();
            this.fillToolStrip.ResumeLayout(false);
            this.fillToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sp_opl_perDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private StoDataSet stoDataSet;
        private System.Windows.Forms.BindingSource sp_opl_perBindingSource;
        private StoDataSetTableAdapters.sp_opl_perTableAdapter sp_opl_perTableAdapter;
        private StoDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator sp_opl_perBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton sp_opl_perBindingNavigatorSaveItem;
        private System.Windows.Forms.ToolStrip fillToolStrip;
        private System.Windows.Forms.ToolStripLabel d1ToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox d1ToolStripTextBox;
        private System.Windows.Forms.ToolStripLabel d2ToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox d2ToolStripTextBox;
        private System.Windows.Forms.ToolStripButton fillToolStripButton;
        private System.Windows.Forms.DataGridView sp_opl_perDataGridView;
        private System.Windows.Forms.Button Запрос;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
    }
}