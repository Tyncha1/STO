﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace STOwinfrmapp
{
    public partial class frm_tp_zakazov : Form
    {
        public frm_tp_zakazov()
        {
            InitializeComponent();
        }

        private void tip_zakazaBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tip_zakazaBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.stoDataSet);

        }

        private void frm_tp_zakazov_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'stoDataSet.tip_zakaza' table. You can move, or remove it, as needed.
            this.tip_zakazaTableAdapter.Fill(this.stoDataSet.tip_zakaza);

        }
    }
}
