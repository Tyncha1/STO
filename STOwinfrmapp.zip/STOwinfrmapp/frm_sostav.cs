﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace STOwinfrmapp
{
    public partial class frm_sostav : Form
    {
        public frm_sostav()
        {
            InitializeComponent();
        }

        private void sostav_zBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.sostav_zBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.stoDataSet);

        }

        private void frm_sostav_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'stoDataSet.sostav_z' table. You can move, or remove it, as needed.
            this.sostav_zTableAdapter.Fill(this.stoDataSet.sostav_z);

        }
    }
}
