﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace STOwinfrmapp
{
    public partial class frm_klien : Form
    {
        public frm_klien()
        {
            InitializeComponent();
        }

        private void klBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.klBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.stoDataSet);

        }

        private void frm_klien_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'stoDataSet.rayon' table. You can move, or remove it, as needed.
            this.rayonTableAdapter.Fill(this.stoDataSet.rayon);
            // TODO: This line of code loads data into the 'stoDataSet.rabota' table. You can move, or remove it, as needed.
            this.rabotaTableAdapter.Fill(this.stoDataSet.rabota);
            // TODO: This line of code loads data into the 'stoDataSet.tip_kl' table. You can move, or remove it, as needed.
            this.tip_klTableAdapter.Fill(this.stoDataSet.tip_kl);
            // TODO: This line of code loads data into the 'stoDataSet.kl' table. You can move, or remove it, as needed.
            this.klTableAdapter.Fill(this.stoDataSet.kl);

        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            

        }

        private void Поиск_Click(object sender, EventArgs e)
        {
            try
            {
                this.klTableAdapter.FillBy(this.stoDataSet.kl, textBox1.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
        }
    }
}
