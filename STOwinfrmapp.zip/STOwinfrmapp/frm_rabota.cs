﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace STOwinfrmapp
{
    public partial class frm_rabota : Form
    {
        public frm_rabota()
        {
            InitializeComponent();
        }

        private void rabotaBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.rabotaBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.stoDataSet);

        }

        private void frm_rabota_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'stoDataSet.tip_rab' table. You can move, or remove it, as needed.
            this.tip_rabTableAdapter.Fill(this.stoDataSet.tip_rab);
            // TODO: This line of code loads data into the 'stoDataSet.rabota' table. You can move, or remove it, as needed.
            this.rabotaTableAdapter.Fill(this.stoDataSet.rabota);

        }
    }
}
