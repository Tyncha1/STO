﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace STOwinfrmapp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void составToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_sostav sos = new frm_sostav();
            sos.ShowDialog();
        }

        private void журналыToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void типКонтактовToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_tp_kont tkn = new frm_tp_kont();
            tkn.ShowDialog();
        }

        private void типЗаказовToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_tp_zakazov tzk = new frm_tp_zakazov();
            tzk.ShowDialog();
        }

        private void оплатаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_opl opl = new frm_opl();
            opl.ShowDialog();
        }

        private void должностиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_dolj dol = new frm_dolj();
            dol.ShowDialog();
        }

        private void типРаботыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_new_tp_rab tprab = new frm_new_tp_rab();
            tprab.ShowDialog();
        }

        private void сотрудникиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_sotr sotr = new frm_sotr();
            sotr.ShowDialog();
        }

        private void ценаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_tsena tsen = new frm_tsena();
            tsen.ShowDialog();
        }

        private void работаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_rabota rab = new frm_rabota();
            rab.ShowDialog();
        }

        private void типАвтоToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_tp_avto tpav = new frm_tp_avto();
            tpav.ShowDialog();
        }

        private void маркаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_mark mr = new frm_mark();
            mr.ShowDialog();
        }

        private void районToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_raion raion = new frm_raion();
            raion.ShowDialog();
        }

        private void типКлиентовToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_tp_kl tpkl = new frm_tp_kl();
            tpkl.ShowDialog();
        }

        private void клиентыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_klien kl = new frm_klien();
            kl.ShowDialog();
        }

        private void заказToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_zkz zk = new frm_zkz();
            zk.ShowDialog();
        }

        private void оплатаToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frm_opl opl = new frm_opl();
            opl.ShowDialog();
        }

        private void прайсЛистToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_pr_list pl = new frm_pr_list();
            pl.ShowDialog();
        }

        private void клиентыToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frm_kont kn = new frm_kont();
            kn.ShowDialog();
        }

        private void актуальныйПрайсЛистToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fq_act_prl acp = new fq_act_prl();
            acp.ShowDialog();
        }

        private void оплатаЗаПериодToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fq_opl_za_per opzaper = new fq_opl_za_per();
            opzaper.ShowDialog();
        }

        private void поРайонамToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fq_po_ray poray = new fq_po_ray();
            poray.ShowDialog();
        }

        private void поТипуАвтоToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fq_po_tp_avt ptavto = new fq_po_tp_avt();
            ptavto.ShowDialog();
        }

        private void маркеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fq_marke mar = new fq_marke();
            mar.ShowDialog();
        }

        private void типуЗаказаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fq_tp_zakaza tzak = new fq_tp_zakaza();
            tzak.ShowDialog();
        }

        private void оплатаЗаПериодToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }
    }
}
