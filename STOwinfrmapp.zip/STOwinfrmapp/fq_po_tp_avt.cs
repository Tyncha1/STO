﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace STOwinfrmapp
{
    public partial class fq_po_tp_avt : Form
    {
        public fq_po_tp_avt()
        {
            InitializeComponent();
        }

        private void tip_avtoBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tip_avtoBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.stoDataSet);

        }

        private void fq_po_tp_avt_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'stoDataSet.sp_st_zak_tip_avrto' table. You can move, or remove it, as needed.
            this.sp_st_zak_tip_avrtoTableAdapter.Fill(this.stoDataSet.sp_st_zak_tip_avrto);
            // TODO: This line of code loads data into the 'stoDataSet.tip_avto' table. You can move, or remove it, as needed.
            this.tip_avtoTableAdapter.Fill(this.stoDataSet.tip_avto);

        }
    }
}
