﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace STOwinfrmapp
{
    public partial class fq_opl_za_per : Form
    {
        public fq_opl_za_per()
        {
            InitializeComponent();
        }

        private void fillToolStripButton_Click(object sender, EventArgs e)
        {
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                this.sp_opl_perTableAdapter.Fill(this.stoDataSet.sp_opl_per, new System.Nullable<System.DateTime>(((System.DateTime)
                    (System.Convert.ChangeType(dateTimePicker1.Value, typeof(System.DateTime))))), 
                    new System.Nullable<System.DateTime>(((System.DateTime)
                    (System.Convert.ChangeType(dateTimePicker2.Value, typeof(System.DateTime))))));
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
        }
    }
}
