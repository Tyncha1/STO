﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace STOwinfrmapp
{
    public partial class frm_opl : Form
    {
        public frm_opl()
        {
            InitializeComponent();
        }

        private void oplataBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.oplataBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.stoDataSet);

        }

        private void frm_opl_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'stoDataSet.marka' table. You can move, or remove it, as needed.
            this.markaTableAdapter.Fill(this.stoDataSet.marka);
            // TODO: This line of code loads data into the 'stoDataSet.tip_zakaza' table. You can move, or remove it, as needed.
            this.tip_zakazaTableAdapter.Fill(this.stoDataSet.tip_zakaza);
            // TODO: This line of code loads data into the 'stoDataSet.tip_avto' table. You can move, or remove it, as needed.
            this.tip_avtoTableAdapter.Fill(this.stoDataSet.tip_avto);
            // TODO: This line of code loads data into the 'stoDataSet.tip_oplaty' table. You can move, or remove it, as needed.
            this.tip_oplatyTableAdapter.Fill(this.stoDataSet.tip_oplaty);
            // TODO: This line of code loads data into the 'stoDataSet.zakaz' table. You can move, or remove it, as needed.
            this.zakazTableAdapter.Fill(this.stoDataSet.zakaz);
            // TODO: This line of code loads data into the 'stoDataSet.rayon' table. You can move, or remove it, as needed.
            this.rayonTableAdapter.Fill(this.stoDataSet.rayon);
            // TODO: This line of code loads data into the 'stoDataSet.kl' table. You can move, or remove it, as needed.
            this.klTableAdapter.Fill(this.stoDataSet.kl);
            // TODO: This line of code loads data into the 'stoDataSet.tip_kl' table. You can move, or remove it, as needed.
            this.tip_klTableAdapter.Fill(this.stoDataSet.tip_kl);
            // TODO: This line of code loads data into the 'stoDataSet.oplata' table. You can move, or remove it, as needed.
            this.oplataTableAdapter.Fill(this.stoDataSet.oplata);

        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                this.klTableAdapter.FillBy(this.stoDataSet.kl, textBox1.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
        }
    }
}
