﻿namespace STOwinfrmapp
{
    partial class frm_zkz
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_zkz));
            this.stoDataSet = new STOwinfrmapp.StoDataSet();
            this.zakazBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.zakazTableAdapter = new STOwinfrmapp.StoDataSetTableAdapters.zakazTableAdapter();
            this.tableAdapterManager = new STOwinfrmapp.StoDataSetTableAdapters.TableAdapterManager();
            this.zakazBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.zakazBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.zakazDataGridView = new System.Windows.Forms.DataGridView();
            this.tip_klBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tip_klTableAdapter = new STOwinfrmapp.StoDataSetTableAdapters.tip_klTableAdapter();
            this.tip_klComboBox = new System.Windows.Forms.ComboBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.fKklidtipkl21B6055DBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.klTableAdapter = new STOwinfrmapp.StoDataSetTableAdapters.klTableAdapter();
            this.rayonBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rayonTableAdapter = new STOwinfrmapp.StoDataSetTableAdapters.rayonTableAdapter();
            this.idklDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.imyaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.famDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.otchDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datarDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mestorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.doljDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.skidkaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pasportnumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idrayonDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.fKzakazidkl34C8D9D1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tipavtoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tip_avtoTableAdapter = new STOwinfrmapp.StoDataSetTableAdapters.tip_avtoTableAdapter();
            this.tipzakazaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tip_zakazaTableAdapter = new STOwinfrmapp.StoDataSetTableAdapters.tip_zakazaTableAdapter();
            this.markaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.markaTableAdapter = new STOwinfrmapp.StoDataSetTableAdapters.markaTableAdapter();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.stoDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zakazBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zakazBindingNavigator)).BeginInit();
            this.zakazBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.zakazDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tip_klBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKklidtipkl21B6055DBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rayonBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKzakazidkl34C8D9D1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tipavtoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tipzakazaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.markaBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // stoDataSet
            // 
            this.stoDataSet.DataSetName = "StoDataSet";
            this.stoDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // zakazBindingSource
            // 
            this.zakazBindingSource.DataMember = "zakaz";
            this.zakazBindingSource.DataSource = this.stoDataSet;
            // 
            // zakazTableAdapter
            // 
            this.zakazTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.doljTableAdapter = null;
            this.tableAdapterManager.klTableAdapter = null;
            this.tableAdapterManager.kontTableAdapter = null;
            this.tableAdapterManager.markaTableAdapter = null;
            this.tableAdapterManager.oplataTableAdapter = null;
            this.tableAdapterManager.priceTableAdapter = null;
            this.tableAdapterManager.rabotaTableAdapter = null;
            this.tableAdapterManager.rayonTableAdapter = null;
            this.tableAdapterManager.sostav_zTableAdapter = null;
            this.tableAdapterManager.sotrTableAdapter = null;
            this.tableAdapterManager.tip_avtoTableAdapter = null;
            this.tableAdapterManager.tip_klTableAdapter = null;
            this.tableAdapterManager.tip_kontTableAdapter = null;
            this.tableAdapterManager.tip_oplatyTableAdapter = null;
            this.tableAdapterManager.tip_rabTableAdapter = null;
            this.tableAdapterManager.tip_zakazaTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = STOwinfrmapp.StoDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.zakazTableAdapter = this.zakazTableAdapter;
            // 
            // zakazBindingNavigator
            // 
            this.zakazBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.zakazBindingNavigator.BindingSource = this.zakazBindingSource;
            this.zakazBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.zakazBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.zakazBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.zakazBindingNavigatorSaveItem});
            this.zakazBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.zakazBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.zakazBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.zakazBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.zakazBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.zakazBindingNavigator.Name = "zakazBindingNavigator";
            this.zakazBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.zakazBindingNavigator.Size = new System.Drawing.Size(1082, 25);
            this.zakazBindingNavigator.TabIndex = 0;
            this.zakazBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // zakazBindingNavigatorSaveItem
            // 
            this.zakazBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.zakazBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("zakazBindingNavigatorSaveItem.Image")));
            this.zakazBindingNavigatorSaveItem.Name = "zakazBindingNavigatorSaveItem";
            this.zakazBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.zakazBindingNavigatorSaveItem.Text = "Save Data";
            this.zakazBindingNavigatorSaveItem.Click += new System.EventHandler(this.zakazBindingNavigatorSaveItem_Click);
            // 
            // zakazDataGridView
            // 
            this.zakazDataGridView.AutoGenerateColumns = false;
            this.zakazDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.zakazDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9});
            this.zakazDataGridView.DataSource = this.fKzakazidkl34C8D9D1BindingSource;
            this.zakazDataGridView.Location = new System.Drawing.Point(12, 267);
            this.zakazDataGridView.Name = "zakazDataGridView";
            this.zakazDataGridView.Size = new System.Drawing.Size(1050, 191);
            this.zakazDataGridView.TabIndex = 1;
            // 
            // tip_klBindingSource
            // 
            this.tip_klBindingSource.DataMember = "tip_kl";
            this.tip_klBindingSource.DataSource = this.stoDataSet;
            // 
            // tip_klTableAdapter
            // 
            this.tip_klTableAdapter.ClearBeforeFill = true;
            // 
            // tip_klComboBox
            // 
            this.tip_klComboBox.DataSource = this.tip_klBindingSource;
            this.tip_klComboBox.DisplayMember = "tip_kl";
            this.tip_klComboBox.FormattingEnabled = true;
            this.tip_klComboBox.Location = new System.Drawing.Point(75, 47);
            this.tip_klComboBox.Name = "tip_klComboBox";
            this.tip_klComboBox.Size = new System.Drawing.Size(300, 21);
            this.tip_klComboBox.TabIndex = 2;
            this.tip_klComboBox.ValueMember = "id_tip_kl";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idklDataGridViewTextBoxColumn,
            this.imyaDataGridViewTextBoxColumn,
            this.famDataGridViewTextBoxColumn,
            this.otchDataGridViewTextBoxColumn,
            this.datarDataGridViewTextBoxColumn,
            this.mestorDataGridViewTextBoxColumn,
            this.doljDataGridViewTextBoxColumn,
            this.skidkaDataGridViewTextBoxColumn,
            this.pasportnumDataGridViewTextBoxColumn,
            this.idrayonDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.fKklidtipkl21B6055DBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 88);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1050, 161);
            this.dataGridView1.TabIndex = 3;
            // 
            // fKklidtipkl21B6055DBindingSource
            // 
            this.fKklidtipkl21B6055DBindingSource.DataMember = "FK__kl__id_tip_kl__21B6055D";
            this.fKklidtipkl21B6055DBindingSource.DataSource = this.tip_klBindingSource;
            // 
            // klTableAdapter
            // 
            this.klTableAdapter.ClearBeforeFill = true;
            // 
            // rayonBindingSource
            // 
            this.rayonBindingSource.DataMember = "rayon";
            this.rayonBindingSource.DataSource = this.stoDataSet;
            // 
            // rayonTableAdapter
            // 
            this.rayonTableAdapter.ClearBeforeFill = true;
            // 
            // idklDataGridViewTextBoxColumn
            // 
            this.idklDataGridViewTextBoxColumn.DataPropertyName = "id_kl";
            this.idklDataGridViewTextBoxColumn.HeaderText = "id_kl";
            this.idklDataGridViewTextBoxColumn.Name = "idklDataGridViewTextBoxColumn";
            this.idklDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // imyaDataGridViewTextBoxColumn
            // 
            this.imyaDataGridViewTextBoxColumn.DataPropertyName = "imya";
            this.imyaDataGridViewTextBoxColumn.HeaderText = "imya";
            this.imyaDataGridViewTextBoxColumn.Name = "imyaDataGridViewTextBoxColumn";
            // 
            // famDataGridViewTextBoxColumn
            // 
            this.famDataGridViewTextBoxColumn.DataPropertyName = "fam";
            this.famDataGridViewTextBoxColumn.HeaderText = "fam";
            this.famDataGridViewTextBoxColumn.Name = "famDataGridViewTextBoxColumn";
            // 
            // otchDataGridViewTextBoxColumn
            // 
            this.otchDataGridViewTextBoxColumn.DataPropertyName = "otch";
            this.otchDataGridViewTextBoxColumn.HeaderText = "otch";
            this.otchDataGridViewTextBoxColumn.Name = "otchDataGridViewTextBoxColumn";
            // 
            // datarDataGridViewTextBoxColumn
            // 
            this.datarDataGridViewTextBoxColumn.DataPropertyName = "data_r";
            this.datarDataGridViewTextBoxColumn.HeaderText = "data_r";
            this.datarDataGridViewTextBoxColumn.Name = "datarDataGridViewTextBoxColumn";
            // 
            // mestorDataGridViewTextBoxColumn
            // 
            this.mestorDataGridViewTextBoxColumn.DataPropertyName = "mesto_r";
            this.mestorDataGridViewTextBoxColumn.HeaderText = "mesto_r";
            this.mestorDataGridViewTextBoxColumn.Name = "mestorDataGridViewTextBoxColumn";
            // 
            // doljDataGridViewTextBoxColumn
            // 
            this.doljDataGridViewTextBoxColumn.DataPropertyName = "dolj";
            this.doljDataGridViewTextBoxColumn.HeaderText = "dolj";
            this.doljDataGridViewTextBoxColumn.Name = "doljDataGridViewTextBoxColumn";
            // 
            // skidkaDataGridViewTextBoxColumn
            // 
            this.skidkaDataGridViewTextBoxColumn.DataPropertyName = "skidka";
            this.skidkaDataGridViewTextBoxColumn.HeaderText = "skidka";
            this.skidkaDataGridViewTextBoxColumn.Name = "skidkaDataGridViewTextBoxColumn";
            // 
            // pasportnumDataGridViewTextBoxColumn
            // 
            this.pasportnumDataGridViewTextBoxColumn.DataPropertyName = "pasport_num";
            this.pasportnumDataGridViewTextBoxColumn.HeaderText = "pasport_num";
            this.pasportnumDataGridViewTextBoxColumn.Name = "pasportnumDataGridViewTextBoxColumn";
            // 
            // idrayonDataGridViewTextBoxColumn
            // 
            this.idrayonDataGridViewTextBoxColumn.DataPropertyName = "id_rayon";
            this.idrayonDataGridViewTextBoxColumn.DataSource = this.rayonBindingSource;
            this.idrayonDataGridViewTextBoxColumn.DisplayMember = "rayon";
            this.idrayonDataGridViewTextBoxColumn.HeaderText = "id_rayon";
            this.idrayonDataGridViewTextBoxColumn.Name = "idrayonDataGridViewTextBoxColumn";
            this.idrayonDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.idrayonDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.idrayonDataGridViewTextBoxColumn.ValueMember = "id_rayon";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(973, 45);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(798, 47);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(169, 20);
            this.textBox1.TabIndex = 5;
            // 
            // fKzakazidkl34C8D9D1BindingSource
            // 
            this.fKzakazidkl34C8D9D1BindingSource.DataMember = "FK__zakaz__id_kl__34C8D9D1";
            this.fKzakazidkl34C8D9D1BindingSource.DataSource = this.fKklidtipkl21B6055DBindingSource;
            // 
            // tipavtoBindingSource
            // 
            this.tipavtoBindingSource.DataMember = "tip_avto";
            this.tipavtoBindingSource.DataSource = this.stoDataSet;
            // 
            // tip_avtoTableAdapter
            // 
            this.tip_avtoTableAdapter.ClearBeforeFill = true;
            // 
            // tipzakazaBindingSource
            // 
            this.tipzakazaBindingSource.DataMember = "tip_zakaza";
            this.tipzakazaBindingSource.DataSource = this.stoDataSet;
            // 
            // tip_zakazaTableAdapter
            // 
            this.tip_zakazaTableAdapter.ClearBeforeFill = true;
            // 
            // markaBindingSource
            // 
            this.markaBindingSource.DataMember = "marka";
            this.markaBindingSource.DataSource = this.stoDataSet;
            // 
            // markaTableAdapter
            // 
            this.markaTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "id_zakaz";
            this.dataGridViewTextBoxColumn1.HeaderText = "id_zakaz";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "data_z";
            this.dataGridViewTextBoxColumn2.HeaderText = "data_z";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "data_g";
            this.dataGridViewTextBoxColumn3.HeaderText = "data_g";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "status_z";
            this.dataGridViewTextBoxColumn4.HeaderText = "status_z";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "opisanie";
            this.dataGridViewTextBoxColumn5.HeaderText = "opisanie";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "nomer_nakladnoi";
            this.dataGridViewTextBoxColumn6.HeaderText = "nomer_nakladnoi";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "id_marka";
            this.dataGridViewTextBoxColumn7.DataSource = this.markaBindingSource;
            this.dataGridViewTextBoxColumn7.DisplayMember = "marka";
            this.dataGridViewTextBoxColumn7.HeaderText = "id_marka";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn7.ValueMember = "id_marka";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "id_tip_zakaza";
            this.dataGridViewTextBoxColumn8.DataSource = this.tipzakazaBindingSource;
            this.dataGridViewTextBoxColumn8.DisplayMember = "tip_zakaza";
            this.dataGridViewTextBoxColumn8.HeaderText = "id_tip_zakaza";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn8.ValueMember = "id_tip_zakaza";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "id_tip_avto";
            this.dataGridViewTextBoxColumn9.DataSource = this.tipavtoBindingSource;
            this.dataGridViewTextBoxColumn9.DisplayMember = "tip_avto";
            this.dataGridViewTextBoxColumn9.HeaderText = "id_tip_avto";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn9.ValueMember = "id_tip_avto";
            // 
            // frm_zkz
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1082, 478);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.tip_klComboBox);
            this.Controls.Add(this.zakazDataGridView);
            this.Controls.Add(this.zakazBindingNavigator);
            this.Name = "frm_zkz";
            this.Text = "frm_zkz";
            this.Load += new System.EventHandler(this.frm_zkz_Load);
            ((System.ComponentModel.ISupportInitialize)(this.stoDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zakazBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zakazBindingNavigator)).EndInit();
            this.zakazBindingNavigator.ResumeLayout(false);
            this.zakazBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.zakazDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tip_klBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKklidtipkl21B6055DBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rayonBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKzakazidkl34C8D9D1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tipavtoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tipzakazaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.markaBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private StoDataSet stoDataSet;
        private System.Windows.Forms.BindingSource zakazBindingSource;
        private StoDataSetTableAdapters.zakazTableAdapter zakazTableAdapter;
        private StoDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator zakazBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton zakazBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView zakazDataGridView;
        private System.Windows.Forms.BindingSource tip_klBindingSource;
        private StoDataSetTableAdapters.tip_klTableAdapter tip_klTableAdapter;
        private System.Windows.Forms.ComboBox tip_klComboBox;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource fKklidtipkl21B6055DBindingSource;
        private StoDataSetTableAdapters.klTableAdapter klTableAdapter;
        private System.Windows.Forms.BindingSource rayonBindingSource;
        private StoDataSetTableAdapters.rayonTableAdapter rayonTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idklDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn imyaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn famDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn otchDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn datarDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mestorDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn doljDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn skidkaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pasportnumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn idrayonDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.BindingSource fKzakazidkl34C8D9D1BindingSource;
        private System.Windows.Forms.BindingSource tipavtoBindingSource;
        private StoDataSetTableAdapters.tip_avtoTableAdapter tip_avtoTableAdapter;
        private System.Windows.Forms.BindingSource tipzakazaBindingSource;
        private StoDataSetTableAdapters.tip_zakazaTableAdapter tip_zakazaTableAdapter;
        private System.Windows.Forms.BindingSource markaBindingSource;
        private StoDataSetTableAdapters.markaTableAdapter markaTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn9;
    }
}