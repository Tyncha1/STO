﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace STOwinfrmapp
{
    public partial class frm_tp_avto : Form
    {
        public frm_tp_avto()
        {
            InitializeComponent();
        }

        private void tip_avtoBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tip_avtoBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.stoDataSet);

        }

        private void frm_tp_avto_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'stoDataSet.tip_avto' table. You can move, or remove it, as needed.
            this.tip_avtoTableAdapter.Fill(this.stoDataSet.tip_avto);

        }
    }
}
