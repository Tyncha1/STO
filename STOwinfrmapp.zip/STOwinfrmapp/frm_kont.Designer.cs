﻿namespace STOwinfrmapp
{
    partial class frm_kont
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_kont));
            this.stoDataSet = new STOwinfrmapp.StoDataSet();
            this.kontBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.kontTableAdapter = new STOwinfrmapp.StoDataSetTableAdapters.kontTableAdapter();
            this.tableAdapterManager = new STOwinfrmapp.StoDataSetTableAdapters.TableAdapterManager();
            this.kontBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.kontBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.kontDataGridView = new System.Windows.Forms.DataGridView();
            this.tip_klBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tip_klTableAdapter = new STOwinfrmapp.StoDataSetTableAdapters.tip_klTableAdapter();
            this.tip_klComboBox = new System.Windows.Forms.ComboBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.fKklidtipkl21B6055DBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.klTableAdapter = new STOwinfrmapp.StoDataSetTableAdapters.klTableAdapter();
            this.fillByToolStrip = new System.Windows.Forms.ToolStrip();
            this.famToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.famToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.fillByToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.rayonBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rayonTableAdapter = new STOwinfrmapp.StoDataSetTableAdapters.rayonTableAdapter();
            this.idklDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.imyaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.famDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.otchDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datarDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mestorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.doljDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.skidkaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pasportnumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idrayonDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.fKkontidkl2B3F6F97BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tipkontBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tip_kontTableAdapter = new STOwinfrmapp.StoDataSetTableAdapters.tip_kontTableAdapter();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.stoDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kontBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kontBindingNavigator)).BeginInit();
            this.kontBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kontDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tip_klBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKklidtipkl21B6055DBindingSource)).BeginInit();
            this.fillByToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rayonBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKkontidkl2B3F6F97BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tipkontBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // stoDataSet
            // 
            this.stoDataSet.DataSetName = "StoDataSet";
            this.stoDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // kontBindingSource
            // 
            this.kontBindingSource.DataMember = "kont";
            this.kontBindingSource.DataSource = this.stoDataSet;
            // 
            // kontTableAdapter
            // 
            this.kontTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.doljTableAdapter = null;
            this.tableAdapterManager.klTableAdapter = null;
            this.tableAdapterManager.kontTableAdapter = this.kontTableAdapter;
            this.tableAdapterManager.markaTableAdapter = null;
            this.tableAdapterManager.oplataTableAdapter = null;
            this.tableAdapterManager.priceTableAdapter = null;
            this.tableAdapterManager.rabotaTableAdapter = null;
            this.tableAdapterManager.rayonTableAdapter = null;
            this.tableAdapterManager.sostav_zTableAdapter = null;
            this.tableAdapterManager.sotrTableAdapter = null;
            this.tableAdapterManager.tip_avtoTableAdapter = null;
            this.tableAdapterManager.tip_klTableAdapter = null;
            this.tableAdapterManager.tip_kontTableAdapter = null;
            this.tableAdapterManager.tip_oplatyTableAdapter = null;
            this.tableAdapterManager.tip_rabTableAdapter = null;
            this.tableAdapterManager.tip_zakazaTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = STOwinfrmapp.StoDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.zakazTableAdapter = null;
            // 
            // kontBindingNavigator
            // 
            this.kontBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.kontBindingNavigator.BindingSource = this.fKkontidkl2B3F6F97BindingSource;
            this.kontBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.kontBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.kontBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.kontBindingNavigatorSaveItem});
            this.kontBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.kontBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.kontBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.kontBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.kontBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.kontBindingNavigator.Name = "kontBindingNavigator";
            this.kontBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.kontBindingNavigator.Size = new System.Drawing.Size(800, 25);
            this.kontBindingNavigator.TabIndex = 0;
            this.kontBindingNavigator.Text = "bindingNavigator1";
            this.kontBindingNavigator.RefreshItems += new System.EventHandler(this.kontBindingNavigator_RefreshItems);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // kontBindingNavigatorSaveItem
            // 
            this.kontBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.kontBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("kontBindingNavigatorSaveItem.Image")));
            this.kontBindingNavigatorSaveItem.Name = "kontBindingNavigatorSaveItem";
            this.kontBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.kontBindingNavigatorSaveItem.Text = "Save Data";
            this.kontBindingNavigatorSaveItem.Click += new System.EventHandler(this.kontBindingNavigatorSaveItem_Click);
            // 
            // kontDataGridView
            // 
            this.kontDataGridView.AutoGenerateColumns = false;
            this.kontDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.kontDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn2});
            this.kontDataGridView.DataSource = this.fKkontidkl2B3F6F97BindingSource;
            this.kontDataGridView.Location = new System.Drawing.Point(21, 289);
            this.kontDataGridView.Name = "kontDataGridView";
            this.kontDataGridView.Size = new System.Drawing.Size(594, 157);
            this.kontDataGridView.TabIndex = 1;
            // 
            // tip_klBindingSource
            // 
            this.tip_klBindingSource.DataMember = "tip_kl";
            this.tip_klBindingSource.DataSource = this.stoDataSet;
            // 
            // tip_klTableAdapter
            // 
            this.tip_klTableAdapter.ClearBeforeFill = true;
            // 
            // tip_klComboBox
            // 
            this.tip_klComboBox.DataSource = this.tip_klBindingSource;
            this.tip_klComboBox.DisplayMember = "tip_kl";
            this.tip_klComboBox.FormattingEnabled = true;
            this.tip_klComboBox.Location = new System.Drawing.Point(21, 72);
            this.tip_klComboBox.Name = "tip_klComboBox";
            this.tip_klComboBox.Size = new System.Drawing.Size(300, 21);
            this.tip_klComboBox.TabIndex = 2;
            this.tip_klComboBox.ValueMember = "id_tip_kl";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idklDataGridViewTextBoxColumn,
            this.imyaDataGridViewTextBoxColumn,
            this.famDataGridViewTextBoxColumn,
            this.otchDataGridViewTextBoxColumn,
            this.datarDataGridViewTextBoxColumn,
            this.mestorDataGridViewTextBoxColumn,
            this.doljDataGridViewTextBoxColumn,
            this.skidkaDataGridViewTextBoxColumn,
            this.pasportnumDataGridViewTextBoxColumn,
            this.idrayonDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.fKklidtipkl21B6055DBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(21, 130);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(711, 133);
            this.dataGridView1.TabIndex = 3;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(684, 69);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(550, 71);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(128, 20);
            this.textBox1.TabIndex = 5;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // fKklidtipkl21B6055DBindingSource
            // 
            this.fKklidtipkl21B6055DBindingSource.DataMember = "FK__kl__id_tip_kl__21B6055D";
            this.fKklidtipkl21B6055DBindingSource.DataSource = this.tip_klBindingSource;
            // 
            // klTableAdapter
            // 
            this.klTableAdapter.ClearBeforeFill = true;
            // 
            // fillByToolStrip
            // 
            this.fillByToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.famToolStripLabel,
            this.famToolStripTextBox,
            this.fillByToolStripButton});
            this.fillByToolStrip.Location = new System.Drawing.Point(0, 25);
            this.fillByToolStrip.Name = "fillByToolStrip";
            this.fillByToolStrip.Size = new System.Drawing.Size(800, 25);
            this.fillByToolStrip.TabIndex = 6;
            this.fillByToolStrip.Text = "fillByToolStrip";
            // 
            // famToolStripLabel
            // 
            this.famToolStripLabel.Name = "famToolStripLabel";
            this.famToolStripLabel.Size = new System.Drawing.Size(31, 22);
            this.famToolStripLabel.Text = "fam:";
            // 
            // famToolStripTextBox
            // 
            this.famToolStripTextBox.Name = "famToolStripTextBox";
            this.famToolStripTextBox.Size = new System.Drawing.Size(100, 23);
            // 
            // fillByToolStripButton
            // 
            this.fillByToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillByToolStripButton.Name = "fillByToolStripButton";
            this.fillByToolStripButton.Size = new System.Drawing.Size(39, 19);
            this.fillByToolStripButton.Text = "FillBy";
            this.fillByToolStripButton.Click += new System.EventHandler(this.fillByToolStripButton_Click);
            // 
            // rayonBindingSource
            // 
            this.rayonBindingSource.DataMember = "rayon";
            this.rayonBindingSource.DataSource = this.stoDataSet;
            // 
            // rayonTableAdapter
            // 
            this.rayonTableAdapter.ClearBeforeFill = true;
            // 
            // idklDataGridViewTextBoxColumn
            // 
            this.idklDataGridViewTextBoxColumn.DataPropertyName = "id_kl";
            this.idklDataGridViewTextBoxColumn.HeaderText = "id_kl";
            this.idklDataGridViewTextBoxColumn.Name = "idklDataGridViewTextBoxColumn";
            this.idklDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // imyaDataGridViewTextBoxColumn
            // 
            this.imyaDataGridViewTextBoxColumn.DataPropertyName = "imya";
            this.imyaDataGridViewTextBoxColumn.HeaderText = "imya";
            this.imyaDataGridViewTextBoxColumn.Name = "imyaDataGridViewTextBoxColumn";
            // 
            // famDataGridViewTextBoxColumn
            // 
            this.famDataGridViewTextBoxColumn.DataPropertyName = "fam";
            this.famDataGridViewTextBoxColumn.HeaderText = "fam";
            this.famDataGridViewTextBoxColumn.Name = "famDataGridViewTextBoxColumn";
            // 
            // otchDataGridViewTextBoxColumn
            // 
            this.otchDataGridViewTextBoxColumn.DataPropertyName = "otch";
            this.otchDataGridViewTextBoxColumn.HeaderText = "otch";
            this.otchDataGridViewTextBoxColumn.Name = "otchDataGridViewTextBoxColumn";
            // 
            // datarDataGridViewTextBoxColumn
            // 
            this.datarDataGridViewTextBoxColumn.DataPropertyName = "data_r";
            this.datarDataGridViewTextBoxColumn.HeaderText = "data_r";
            this.datarDataGridViewTextBoxColumn.Name = "datarDataGridViewTextBoxColumn";
            // 
            // mestorDataGridViewTextBoxColumn
            // 
            this.mestorDataGridViewTextBoxColumn.DataPropertyName = "mesto_r";
            this.mestorDataGridViewTextBoxColumn.HeaderText = "mesto_r";
            this.mestorDataGridViewTextBoxColumn.Name = "mestorDataGridViewTextBoxColumn";
            // 
            // doljDataGridViewTextBoxColumn
            // 
            this.doljDataGridViewTextBoxColumn.DataPropertyName = "dolj";
            this.doljDataGridViewTextBoxColumn.HeaderText = "dolj";
            this.doljDataGridViewTextBoxColumn.Name = "doljDataGridViewTextBoxColumn";
            // 
            // skidkaDataGridViewTextBoxColumn
            // 
            this.skidkaDataGridViewTextBoxColumn.DataPropertyName = "skidka";
            this.skidkaDataGridViewTextBoxColumn.HeaderText = "skidka";
            this.skidkaDataGridViewTextBoxColumn.Name = "skidkaDataGridViewTextBoxColumn";
            // 
            // pasportnumDataGridViewTextBoxColumn
            // 
            this.pasportnumDataGridViewTextBoxColumn.DataPropertyName = "pasport_num";
            this.pasportnumDataGridViewTextBoxColumn.HeaderText = "pasport_num";
            this.pasportnumDataGridViewTextBoxColumn.Name = "pasportnumDataGridViewTextBoxColumn";
            // 
            // idrayonDataGridViewTextBoxColumn
            // 
            this.idrayonDataGridViewTextBoxColumn.DataPropertyName = "id_rayon";
            this.idrayonDataGridViewTextBoxColumn.DataSource = this.rayonBindingSource;
            this.idrayonDataGridViewTextBoxColumn.DisplayMember = "rayon";
            this.idrayonDataGridViewTextBoxColumn.HeaderText = "id_rayon";
            this.idrayonDataGridViewTextBoxColumn.Name = "idrayonDataGridViewTextBoxColumn";
            this.idrayonDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.idrayonDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.idrayonDataGridViewTextBoxColumn.ValueMember = "id_rayon";
            // 
            // fKkontidkl2B3F6F97BindingSource
            // 
            this.fKkontidkl2B3F6F97BindingSource.DataMember = "FK__kont__id_kl__2B3F6F97";
            this.fKkontidkl2B3F6F97BindingSource.DataSource = this.fKklidtipkl21B6055DBindingSource;
            // 
            // tipkontBindingSource
            // 
            this.tipkontBindingSource.DataMember = "tip_kont";
            this.tipkontBindingSource.DataSource = this.stoDataSet;
            // 
            // tip_kontTableAdapter
            // 
            this.tip_kontTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "id_kont";
            this.dataGridViewTextBoxColumn1.HeaderText = "id_kont";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "tip_kont";
            this.dataGridViewTextBoxColumn4.DataSource = this.tipkontBindingSource;
            this.dataGridViewTextBoxColumn4.DisplayMember = "tip_kont";
            this.dataGridViewTextBoxColumn4.HeaderText = "tip_kont";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn4.ValueMember = "id_tip_kont";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "kont";
            this.dataGridViewTextBoxColumn2.HeaderText = "kont";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // frm_kont
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 466);
            this.Controls.Add(this.fillByToolStrip);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.tip_klComboBox);
            this.Controls.Add(this.kontDataGridView);
            this.Controls.Add(this.kontBindingNavigator);
            this.Name = "frm_kont";
            this.Text = "frm_kont";
            this.Load += new System.EventHandler(this.frm_kont_Load);
            ((System.ComponentModel.ISupportInitialize)(this.stoDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kontBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kontBindingNavigator)).EndInit();
            this.kontBindingNavigator.ResumeLayout(false);
            this.kontBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kontDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tip_klBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKklidtipkl21B6055DBindingSource)).EndInit();
            this.fillByToolStrip.ResumeLayout(false);
            this.fillByToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rayonBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKkontidkl2B3F6F97BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tipkontBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private StoDataSet stoDataSet;
        private System.Windows.Forms.BindingSource kontBindingSource;
        private StoDataSetTableAdapters.kontTableAdapter kontTableAdapter;
        private StoDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator kontBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton kontBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView kontDataGridView;
        private System.Windows.Forms.BindingSource tip_klBindingSource;
        private StoDataSetTableAdapters.tip_klTableAdapter tip_klTableAdapter;
        private System.Windows.Forms.ComboBox tip_klComboBox;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.BindingSource fKklidtipkl21B6055DBindingSource;
        private StoDataSetTableAdapters.klTableAdapter klTableAdapter;
        private System.Windows.Forms.ToolStrip fillByToolStrip;
        private System.Windows.Forms.ToolStripLabel famToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox famToolStripTextBox;
        private System.Windows.Forms.ToolStripButton fillByToolStripButton;
        private System.Windows.Forms.BindingSource rayonBindingSource;
        private StoDataSetTableAdapters.rayonTableAdapter rayonTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idklDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn imyaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn famDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn otchDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn datarDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mestorDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn doljDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn skidkaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pasportnumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn idrayonDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource fKkontidkl2B3F6F97BindingSource;
        private System.Windows.Forms.BindingSource tipkontBindingSource;
        private StoDataSetTableAdapters.tip_kontTableAdapter tip_kontTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
    }
}